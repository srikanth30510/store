import { 
  users, 
  stores, 
  ratings, 
  type User, 
  type InsertUser, 
  type Store, 
  type InsertStore, 
  type Rating, 
  type InsertRating 
} from "@shared/schema";

import { db } from "./db";
import { eq, and, desc, asc, count, avg, sql, like } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPassword(id: number, hashedPassword: string): Promise<void>;
  getAllUsers(): Promise<User[]>;
  getUsersByRole(role: 'admin' | 'user' | 'store_owner'): Promise<User[]>;
  searchUsers(query: string): Promise<User[]>;
  
  // Store methods
  getStore(id: number): Promise<Store | undefined>;
  getStoreByEmail(email: string): Promise<Store | undefined>;
  createStore(store: InsertStore): Promise<Store>;
  getAllStores(): Promise<Store[]>;
  searchStores(query: string): Promise<Store[]>;
  getStoreWithAvgRating(id: number): Promise<(Store & { avgRating: number }) | undefined>;
  getAllStoresWithAvgRating(): Promise<(Store & { avgRating: number, totalRatings: number })[]>;
  
  // Rating methods
  createRating(rating: InsertRating): Promise<Rating>;
  updateRating(userId: number, storeId: number, rating: number): Promise<Rating>;
  getRatingByUserAndStore(userId: number, storeId: number): Promise<Rating | undefined>;
  getRatingsByStoreId(storeId: number): Promise<(Rating & { user: { name: string, email: string } })[]>;
  getAverageRatingForStore(storeId: number): Promise<number>;
  getTotalRatingCount(): Promise<number>;
  getRatingDistributionForStore(storeId: number): Promise<{ rating: number, count: number }[]>;
  
  // Statistics methods
  getDashboardStatistics(): Promise<{ totalUsers: number, totalStores: number, totalRatings: number }>;
  
  // Session store
  sessionStore: session.Store;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool: db.$pool,
      createTableIfMissing: true,
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUserPassword(id: number, hashedPassword: string): Promise<void> {
    await db.update(users)
      .set({ password: hashedPassword })
      .where(eq(users.id, id));
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async getUsersByRole(role: 'admin' | 'user' | 'store_owner'): Promise<User[]> {
    return await db.select().from(users).where(eq(users.role, role));
  }

  async searchUsers(query: string): Promise<User[]> {
    return await db.select().from(users).where(
      sql`(${users.name} ILIKE ${`%${query}%`} OR ${users.email} ILIKE ${`%${query}%`} OR ${users.address} ILIKE ${`%${query}%`})`
    );
  }

  // Store methods
  async getStore(id: number): Promise<Store | undefined> {
    const [store] = await db.select().from(stores).where(eq(stores.id, id));
    return store;
  }

  async getStoreByEmail(email: string): Promise<Store | undefined> {
    const [store] = await db.select().from(stores).where(eq(stores.email, email));
    return store;
  }

  async createStore(insertStore: InsertStore): Promise<Store> {
    const [store] = await db.insert(stores).values(insertStore).returning();
    return store;
  }

  async getAllStores(): Promise<Store[]> {
    return await db.select().from(stores);
  }

  async searchStores(query: string): Promise<Store[]> {
    return await db.select().from(stores).where(
      sql`(${stores.name} ILIKE ${`%${query}%`} OR ${stores.address} ILIKE ${`%${query}%`})`
    );
  }

  async getStoreWithAvgRating(id: number): Promise<(Store & { avgRating: number }) | undefined> {
    const result = await db
      .select({
        ...stores,
        avgRating: sql<number>`COALESCE(AVG(${ratings.rating}), 0)`.as('avg_rating'),
      })
      .from(stores)
      .leftJoin(ratings, eq(stores.id, ratings.storeId))
      .where(eq(stores.id, id))
      .groupBy(stores.id);
    
    return result[0];
  }

  async getAllStoresWithAvgRating(): Promise<(Store & { avgRating: number, totalRatings: number })[]> {
    return await db
      .select({
        ...stores,
        avgRating: sql<number>`COALESCE(AVG(${ratings.rating}), 0)`.as('avg_rating'),
        totalRatings: sql<number>`COUNT(${ratings.id})`.as('total_ratings'),
      })
      .from(stores)
      .leftJoin(ratings, eq(stores.id, ratings.storeId))
      .groupBy(stores.id);
  }

  // Rating methods
  async createRating(insertRating: InsertRating): Promise<Rating> {
    const [rating] = await db.insert(ratings).values(insertRating).returning();
    return rating;
  }

  async updateRating(userId: number, storeId: number, rating: number): Promise<Rating> {
    const [updatedRating] = await db
      .update(ratings)
      .set({ rating })
      .where(and(eq(ratings.userId, userId), eq(ratings.storeId, storeId)))
      .returning();
    return updatedRating;
  }

  async getRatingByUserAndStore(userId: number, storeId: number): Promise<Rating | undefined> {
    const [rating] = await db
      .select()
      .from(ratings)
      .where(and(eq(ratings.userId, userId), eq(ratings.storeId, storeId)));
    return rating;
  }

  async getRatingsByStoreId(storeId: number): Promise<(Rating & { user: { name: string, email: string } })[]> {
    return await db
      .select({
        ...ratings,
        user: {
          name: users.name,
          email: users.email,
        },
      })
      .from(ratings)
      .innerJoin(users, eq(ratings.userId, users.id))
      .where(eq(ratings.storeId, storeId))
      .orderBy(desc(ratings.createdAt));
  }

  async getAverageRatingForStore(storeId: number): Promise<number> {
    const [result] = await db
      .select({
        avgRating: sql<number>`COALESCE(AVG(${ratings.rating}), 0)`.as('avg_rating'),
      })
      .from(ratings)
      .where(eq(ratings.storeId, storeId));
    
    return result?.avgRating ?? 0;
  }

  async getTotalRatingCount(): Promise<number> {
    const [result] = await db
      .select({
        count: count(),
      })
      .from(ratings);
    
    return result?.count ?? 0;
  }

  async getRatingDistributionForStore(storeId: number): Promise<{ rating: number, count: number }[]> {
    const distribution = await db
      .select({
        rating: ratings.rating,
        count: count(),
      })
      .from(ratings)
      .where(eq(ratings.storeId, storeId))
      .groupBy(ratings.rating)
      .orderBy(desc(ratings.rating));
    
    // Ensure all ratings 1-5 are represented
    const result: { rating: number, count: number }[] = [];
    for (let i = 5; i >= 1; i--) {
      const found = distribution.find(d => d.rating === i);
      result.push({ rating: i, count: found?.count ?? 0 });
    }
    
    return result;
  }

  // Statistics methods
  async getDashboardStatistics(): Promise<{ totalUsers: number, totalStores: number, totalRatings: number }> {
    const [userResult] = await db.select({ count: count() }).from(users);
    const [storeResult] = await db.select({ count: count() }).from(stores);
    const [ratingResult] = await db.select({ count: count() }).from(ratings);
    
    return {
      totalUsers: userResult?.count ?? 0,
      totalStores: storeResult?.count ?? 0,
      totalRatings: ratingResult?.count ?? 0,
    };
  }
}

export const storage = new DatabaseStorage();
