import { drizzle } from "drizzle-orm/neon-serverless";
import { neonConfig, Pool } from "@neondatabase/serverless";
import { z } from "zod";
import WebSocket from "ws";

// Parse database config from environment variables
const dbConfigSchema = z.object({
  host: z.string(),
  port: z.coerce.number(),
  user: z.string(),
  password: z.string(),
  database: z.string(),
});

const dbConfig = dbConfigSchema.parse({
  host: process.env.PGHOST,
  port: process.env.PGPORT,
  user: process.env.PGUSER,
  password: process.env.PGPASSWORD,
  database: process.env.PGDATABASE,
});

// Configure neon with WebSocket
neonConfig.webSocketConstructor = WebSocket;

// Create connection pool
const pool = new Pool({
  host: dbConfig.host,
  port: dbConfig.port,
  user: dbConfig.user,
  password: dbConfig.password,
  database: dbConfig.database,
  max: 10,
  ssl: true,
});

// Initialize Drizzle ORM
export const db = drizzle(pool);
