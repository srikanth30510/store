import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { hashPassword } from "./auth";
import { insertStoreSchema, insertUserSchema, insertRatingSchema, passwordUpdateSchema } from "@shared/schema";
import { z } from "zod";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

// Middleware to check if user is authenticated
const isAuthenticated = (req: Request, res: Response, next: Function) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
};

// Middleware to check if user is an admin
const isAdmin = (req: Request, res: Response, next: Function) => {
  if (req.isAuthenticated() && req.user.role === "admin") {
    return next();
  }
  res.status(403).json({ message: "Forbidden: Admin access required" });
};

// Middleware to check if user is a store owner
const isStoreOwner = (req: Request, res: Response, next: Function) => {
  if (req.isAuthenticated() && req.user.role === "store_owner") {
    return next();
  }
  res.status(403).json({ message: "Forbidden: Store owner access required" });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // sets up /api/register, /api/login, /api/logout, /api/user
  setupAuth(app);

  // Error handler for zod validation errors
  const handleZodError = (err: unknown, res: Response) => {
    if (err instanceof ZodError) {
      const validationError = fromZodError(err);
      return res.status(400).json({ message: validationError.message });
    }
    return res.status(500).json({ message: "Internal server error" });
  };

  // Admin Routes
  
  // Get dashboard statistics
  app.get("/api/admin/statistics", isAdmin, async (req, res) => {
    try {
      const stats = await storage.getDashboardStatistics();
      res.json(stats);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch statistics" });
    }
  });
  
  // Add a new store
  app.post("/api/admin/stores", isAdmin, async (req, res) => {
    try {
      const storeData = insertStoreSchema.parse(req.body);
      const store = await storage.createStore(storeData);
      
      // If a store owner email is provided, create the store owner user
      if (req.body.ownerEmail && req.body.ownerPassword && req.body.ownerName && req.body.ownerAddress) {
        const ownerData = {
          name: req.body.ownerName,
          email: req.body.ownerEmail,
          password: await hashPassword(req.body.ownerPassword),
          address: req.body.ownerAddress,
          role: "store_owner" as const,
          storeId: store.id
        };
        
        await storage.createUser(ownerData);
      }
      
      res.status(201).json(store);
    } catch (err) {
      handleZodError(err, res);
    }
  });
  
  // Add a new user (admin only)
  app.post("/api/admin/users", isAdmin, async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const hashedPassword = await hashPassword(userData.password);
      
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword
      });
      
      // Don't return the password
      const { password, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (err) {
      handleZodError(err, res);
    }
  });
  
  // Get all stores with their average ratings
  app.get("/api/admin/stores", isAdmin, async (req, res) => {
    try {
      const stores = await storage.getAllStoresWithAvgRating();
      res.json(stores);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch stores" });
    }
  });
  
  // Get all users
  app.get("/api/admin/users", isAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      // Don't return passwords
      const usersWithoutPasswords = users.map(user => {
        const { password, ...userWithoutPassword } = user;
        return userWithoutPassword;
      });
      res.json(usersWithoutPasswords);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });
  
  // Search users
  app.get("/api/admin/users/search", isAdmin, async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ message: "Query parameter 'q' is required" });
      }
      
      const users = await storage.searchUsers(query);
      // Don't return passwords
      const usersWithoutPasswords = users.map(user => {
        const { password, ...userWithoutPassword } = user;
        return userWithoutPassword;
      });
      res.json(usersWithoutPasswords);
    } catch (err) {
      res.status(500).json({ message: "Failed to search users" });
    }
  });
  
  // Filter users by role
  app.get("/api/admin/users/filter/:role", isAdmin, async (req, res) => {
    try {
      const role = req.params.role as 'admin' | 'user' | 'store_owner';
      if (!['admin', 'user', 'store_owner'].includes(role)) {
        return res.status(400).json({ message: "Invalid role parameter" });
      }
      
      const users = await storage.getUsersByRole(role);
      // Don't return passwords
      const usersWithoutPasswords = users.map(user => {
        const { password, ...userWithoutPassword } = user;
        return userWithoutPassword;
      });
      res.json(usersWithoutPasswords);
    } catch (err) {
      res.status(500).json({ message: "Failed to filter users" });
    }
  });
  
  // Normal User Routes
  
  // Add a new store
  app.post("/api/stores", isAuthenticated, async (req, res) => {
    try {
      const storeData = insertStoreSchema.parse(req.body);
      const store = await storage.createStore(storeData);
      res.status(201).json(store);
    } catch (err) {
      handleZodError(err, res);
    }
  });
  
  // Get all stores with ratings for display to normal users
  app.get("/api/stores", isAuthenticated, async (req, res) => {
    try {
      const stores = await storage.getAllStoresWithAvgRating();
      
      // If the user is logged in, get their ratings for each store
      const userId = req.user.id;
      const storesWithUserRatings = await Promise.all(stores.map(async (store) => {
        const userRating = await storage.getRatingByUserAndStore(userId, store.id);
        return {
          ...store,
          userRating: userRating?.rating || null
        };
      }));
      
      res.json(storesWithUserRatings);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch stores" });
    }
  });
  
  // Search stores
  app.get("/api/stores/search", isAuthenticated, async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ message: "Query parameter 'q' is required" });
      }
      
      const stores = await storage.searchStores(query);
      
      // Add average ratings
      const storesWithRatings = await Promise.all(stores.map(async (store) => {
        const avgRating = await storage.getAverageRatingForStore(store.id);
        const userRating = await storage.getRatingByUserAndStore(req.user.id, store.id);
        const totalRatings = (await storage.getRatingsByStoreId(store.id)).length;
        
        return {
          ...store,
          avgRating,
          totalRatings,
          userRating: userRating?.rating || null
        };
      }));
      
      res.json(storesWithRatings);
    } catch (err) {
      res.status(500).json({ message: "Failed to search stores" });
    }
  });
  
  // Submit a rating
  app.post("/api/stores/:storeId/rate", isAuthenticated, async (req, res) => {
    try {
      const storeId = parseInt(req.params.storeId);
      if (isNaN(storeId)) {
        return res.status(400).json({ message: "Invalid store ID" });
      }
      
      // Verify the store exists
      const store = await storage.getStore(storeId);
      if (!store) {
        return res.status(404).json({ message: "Store not found" });
      }
      
      const ratingValue = insertRatingSchema.shape.rating.parse(req.body.rating);
      const userId = req.user.id;
      
      // Check if the user is the owner of this store (store owners shouldn't rate their own stores)
      if (req.user.role === 'store_owner' && req.user.storeId === storeId) {
        return res.status(403).json({ message: "Store owners cannot rate their own stores" });
      }
      
      // Check if user already rated this store
      const existingRating = await storage.getRatingByUserAndStore(userId, storeId);
      
      let rating;
      if (existingRating) {
        // Update existing rating
        rating = await storage.updateRating(userId, storeId, ratingValue);
      } else {
        // Create new rating
        rating = await storage.createRating({
          userId,
          storeId,
          rating: ratingValue
        });
      }
      
      res.status(201).json(rating);
    } catch (err) {
      handleZodError(err, res);
    }
  });
  
  // Get rating for a specific store by the logged-in user
  app.get("/api/stores/:storeId/rating", isAuthenticated, async (req, res) => {
    try {
      const storeId = parseInt(req.params.storeId);
      if (isNaN(storeId)) {
        return res.status(400).json({ message: "Invalid store ID" });
      }
      
      const userId = req.user.id;
      const rating = await storage.getRatingByUserAndStore(userId, storeId);
      
      if (!rating) {
        return res.status(404).json({ message: "Rating not found" });
      }
      
      res.json(rating);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch rating" });
    }
  });
  
  // Get full details for a single store (with ratings distribution for regular users)
  app.get("/api/stores/:storeId", isAuthenticated, async (req, res) => {
    try {
      const storeId = parseInt(req.params.storeId);
      if (isNaN(storeId)) {
        return res.status(400).json({ message: "Invalid store ID" });
      }
      
      const store = await storage.getStoreWithAvgRating(storeId);
      if (!store) {
        return res.status(404).json({ message: "Store not found" });
      }
      
      const userId = req.user.id;
      const userRating = await storage.getRatingByUserAndStore(userId, storeId);
      const totalRatings = (await storage.getRatingsByStoreId(storeId)).length;
      const ratingDistribution = await storage.getRatingDistributionForStore(storeId);
      
      res.json({
        ...store,
        userRating: userRating?.rating || null,
        totalRatings,
        ratingDistribution
      });
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch store details" });
    }
  });
  
  // Get all ratings for a store
  app.get("/api/stores/:storeId/ratings", isAuthenticated, async (req, res) => {
    try {
      const storeId = parseInt(req.params.storeId);
      if (isNaN(storeId)) {
        return res.status(400).json({ message: "Invalid store ID" });
      }
      
      const ratings = await storage.getRatingsByStoreId(storeId);
      res.json(ratings);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch ratings" });
    }
  });
  
  // Update password (for all user types)
  app.post("/api/update-password", isAuthenticated, async (req, res) => {
    try {
      // Validation is handled in auth.ts
      // This is just a route to forward to the auth handler
      res.status(400).json({ message: "Invalid request" });
    } catch (err) {
      handleZodError(err, res);
    }
  });
  
  // Store Owner Routes
  
  // Get store details for the logged-in store owner
  app.get("/api/store-owner/store", isStoreOwner, async (req, res) => {
    try {
      const storeId = req.user.storeId;
      if (!storeId) {
        return res.status(400).json({ message: "No store associated with this account" });
      }
      
      const store = await storage.getStoreWithAvgRating(storeId);
      if (!store) {
        return res.status(404).json({ message: "Store not found" });
      }
      
      const totalRatings = (await storage.getRatingsByStoreId(storeId)).length;
      const ratingDistribution = await storage.getRatingDistributionForStore(storeId);
      
      res.json({
        ...store,
        totalRatings,
        ratingDistribution
      });
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch store details" });
    }
  });
  
  // Get ratings for the store owner's store
  app.get("/api/store-owner/ratings", isStoreOwner, async (req, res) => {
    try {
      const storeId = req.user.storeId;
      if (!storeId) {
        return res.status(400).json({ message: "No store associated with this account" });
      }
      
      const ratings = await storage.getRatingsByStoreId(storeId);
      res.json(ratings);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch ratings" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
