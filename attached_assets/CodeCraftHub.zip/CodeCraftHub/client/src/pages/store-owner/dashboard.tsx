import { useQuery } from "@tanstack/react-query";
import { MainLayout } from "@/components/layout/main-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { StarRating } from "@/components/shared/star-rating";
import { RatingDistribution } from "@/components/shared/rating-distribution";
import { Pagination } from "@/components/shared/pagination";
import { Store } from "@shared/schema";
import { useState } from "react";

interface StoreWithDetails extends Store {
  avgRating: number;
  totalRatings: number;
  ratingDistribution: { rating: number; count: number }[];
}

interface UserRating {
  id: number;
  userId: number;
  storeId: number;
  rating: number;
  createdAt: string;
  user: {
    name: string;
    email: string;
  };
}

export default function StoreDashboard() {
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  const { data: storeData, isLoading: isStoreLoading } = useQuery<StoreWithDetails>({
    queryKey: ["/api/store-owner/store"],
  });

  const { data: ratings, isLoading: isRatingsLoading } = useQuery<UserRating[]>({
    queryKey: ["/api/store-owner/ratings"],
  });

  // Pagination for ratings
  const totalPages = Math.ceil((ratings?.length || 0) / itemsPerPage);
  const paginatedRatings = ratings
    ? ratings.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage)
    : [];

  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date);
  };

  return (
    <MainLayout>
      <div className="space-y-6">
        <h1 className="text-2xl font-bold">Store Dashboard</h1>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Average Rating Card */}
          <Card>
            <CardContent className="p-6">
              {isStoreLoading ? (
                <div className="animate-pulse space-y-3">
                  <div className="h-4 bg-gray-200 rounded w-1/3"></div>
                  <div className="h-10 bg-gray-200 rounded w-1/4"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                </div>
              ) : (
                <>
                  <p className="text-muted-foreground text-sm">Average Rating</p>
                  <div className="flex items-center mt-2">
                    <span className="text-4xl font-bold mr-3">
                      {storeData?.avgRating.toFixed(1) || "0.0"}
                    </span>
                    <StarRating rating={storeData?.avgRating || 0} size="large" />
                  </div>
                  <p className="text-muted-foreground text-sm mt-2">
                    Based on {storeData?.totalRatings || 0} ratings
                  </p>
                </>
              )}
            </CardContent>
          </Card>

          {/* Rating Breakdown Card */}
          <Card>
            <CardContent className="p-6">
              <p className="text-muted-foreground text-sm mb-4">Rating Distribution</p>
              {isStoreLoading ? (
                <div className="animate-pulse space-y-3">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <div className="h-4 bg-gray-200 rounded w-16"></div>
                      <div className="h-2.5 bg-gray-200 rounded w-full"></div>
                      <div className="h-4 bg-gray-200 rounded w-8"></div>
                    </div>
                  ))}
                </div>
              ) : (
                <RatingDistribution 
                  distribution={storeData?.ratingDistribution || []}
                  totalRatings={storeData?.totalRatings || 0}
                />
              )}
            </CardContent>
          </Card>
        </div>

        {/* Recent Ratings Table */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Ratings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Rating</TableHead>
                    <TableHead>Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isRatingsLoading ? (
                    <TableRow>
                      <TableCell colSpan={3} className="text-center py-10">
                        <div className="flex justify-center">
                          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                        </div>
                      </TableCell>
                    </TableRow>
                  ) : paginatedRatings.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={3} className="text-center py-10 text-muted-foreground">
                        No ratings have been submitted yet
                      </TableCell>
                    </TableRow>
                  ) : (
                    paginatedRatings.map((rating) => (
                      <TableRow key={rating.id}>
                        <TableCell className="whitespace-nowrap font-medium">
                          {rating.user.name}
                        </TableCell>
                        <TableCell>
                          <div className="flex">
                            <StarRating rating={rating.rating} />
                          </div>
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-muted-foreground">
                          {formatDate(rating.createdAt)}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="mt-4">
                <Pagination
                  currentPage={currentPage}
                  totalPages={totalPages}
                  onPageChange={setCurrentPage}
                />
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
