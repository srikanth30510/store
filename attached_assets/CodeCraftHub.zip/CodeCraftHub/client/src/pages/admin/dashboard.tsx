import { useQuery } from "@tanstack/react-query";
import { MainLayout } from "@/components/layout/main-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { AddStoreModal } from "@/components/modals/add-store-modal";
import { AddUserModal } from "@/components/modals/add-user-modal";
import { useState } from "react";
import { Loader2, Users, Store, Star, Plus, UserPlus } from "lucide-react";

interface DashboardStats {
  totalUsers: number;
  totalStores: number;
  totalRatings: number;
}

export default function AdminDashboard() {
  const [isAddStoreModalOpen, setIsAddStoreModalOpen] = useState(false);
  const [isAddUserModalOpen, setIsAddUserModalOpen] = useState(false);

  const { data: stats, isLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/admin/statistics"],
  });

  const mockActivityLogs = [
    { action: "New rating submitted", user: "Daniel Johnson", details: "Rated Coffee Express with 4 stars", time: "Today, 2:30 PM" },
    { action: "New user registered", user: "Sarah Williams", details: "Completed registration", time: "Today, 11:15 AM" },
    { action: "Store added", user: "Admin", details: 'Added "Bistro Garden" to the platform', time: "Yesterday, 4:10 PM" },
  ];

  return (
    <MainLayout>
      <div className="space-y-6">
        <h1 className="text-2xl font-bold">Admin Dashboard</h1>

        {/* Stats Cards */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="p-6 animate-pulse">
                <div className="h-20 bg-gray-200 rounded"></div>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Total Users Card */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm">Total Users</p>
                    <h2 className="text-3xl font-bold">{stats?.totalUsers || 0}</h2>
                  </div>
                  <div className="bg-primary/20 rounded-full w-12 h-12 flex items-center justify-center text-primary">
                    <Users className="h-6 w-6" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Total Stores Card */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm">Total Stores</p>
                    <h2 className="text-3xl font-bold">{stats?.totalStores || 0}</h2>
                  </div>
                  <div className="bg-secondary/20 rounded-full w-12 h-12 flex items-center justify-center text-secondary">
                    <Store className="h-6 w-6" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Total Ratings Card */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-muted-foreground text-sm">Total Ratings</p>
                    <h2 className="text-3xl font-bold">{stats?.totalRatings || 0}</h2>
                  </div>
                  <div className="bg-yellow-500/20 rounded-full w-12 h-12 flex items-center justify-center text-yellow-500">
                    <Star className="h-6 w-6" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Quick Actions Section */}
        <Card>
          <CardContent className="p-6">
            <h2 className="text-xl font-medium mb-4">Quick Actions</h2>
            <div className="flex flex-wrap gap-4">
              <Button onClick={() => setIsAddStoreModalOpen(true)}>
                <Plus className="h-4 w-4 mr-2" /> Add Store
              </Button>
              <Button onClick={() => setIsAddUserModalOpen(true)}>
                <UserPlus className="h-4 w-4 mr-2" /> Add User
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity Section */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Action</TableHead>
                    <TableHead>User</TableHead>
                    <TableHead>Details</TableHead>
                    <TableHead>Time</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoading ? (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center py-6">
                        <Loader2 className="h-8 w-8 animate-spin mx-auto text-muted-foreground" />
                      </TableCell>
                    </TableRow>
                  ) : mockActivityLogs.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center py-6 text-muted-foreground">
                        No recent activity to display
                      </TableCell>
                    </TableRow>
                  ) : (
                    mockActivityLogs.map((log, index) => (
                      <TableRow key={index}>
                        <TableCell className="whitespace-nowrap">{log.action}</TableCell>
                        <TableCell className="whitespace-nowrap">{log.user}</TableCell>
                        <TableCell>{log.details}</TableCell>
                        <TableCell className="whitespace-nowrap">{log.time}</TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Modals */}
      <AddStoreModal 
        isOpen={isAddStoreModalOpen} 
        onClose={() => setIsAddStoreModalOpen(false)} 
      />
      <AddUserModal 
        isOpen={isAddUserModalOpen} 
        onClose={() => setIsAddUserModalOpen(false)} 
      />
    </MainLayout>
  );
}
