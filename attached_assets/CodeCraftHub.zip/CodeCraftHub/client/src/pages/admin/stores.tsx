import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { MainLayout } from "@/components/layout/main-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { StarRating } from "@/components/shared/star-rating";
import { Pagination } from "@/components/shared/pagination";
import { AddStoreModal } from "@/components/modals/add-store-modal";
import { Store } from "@shared/schema";
import { Eye, Edit, Search, Plus } from "lucide-react";

interface StoreWithRating extends Store {
  avgRating: number;
  totalRatings: number;
}

export default function AdminStores() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterBy, setFilterBy] = useState("all");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");
  const [sortField, setSortField] = useState("name");
  const [currentPage, setCurrentPage] = useState(1);
  const [isAddStoreModalOpen, setIsAddStoreModalOpen] = useState(false);
  const itemsPerPage = 10;

  const { data: stores, isLoading } = useQuery<StoreWithRating[]>({
    queryKey: ["/api/admin/stores"],
  });

  // Handle search and filter
  const filteredStores = stores
    ? stores
        .filter((store) => {
          const matchesSearch =
            searchTerm === "" ||
            store.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            store.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
            store.address.toLowerCase().includes(searchTerm.toLowerCase());

          if (filterBy === "all") return matchesSearch;
          if (filterBy === "high-rated") return matchesSearch && store.avgRating >= 4;
          if (filterBy === "low-rated") return matchesSearch && store.avgRating < 3;
          return matchesSearch;
        })
        .sort((a, b) => {
          if (sortField === "name") {
            return sortDirection === "asc"
              ? a.name.localeCompare(b.name)
              : b.name.localeCompare(a.name);
          } else if (sortField === "email") {
            return sortDirection === "asc"
              ? a.email.localeCompare(b.email)
              : b.email.localeCompare(a.email);
          } else if (sortField === "address") {
            return sortDirection === "asc"
              ? a.address.localeCompare(b.address)
              : b.address.localeCompare(a.address);
          } else if (sortField === "rating") {
            return sortDirection === "asc" 
              ? a.avgRating - b.avgRating 
              : b.avgRating - a.avgRating;
          }
          return 0;
        })
    : [];

  // Pagination
  const totalPages = Math.ceil((filteredStores?.length || 0) / itemsPerPage);
  const paginatedStores = filteredStores.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  // Sort handlers
  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  // Get sort indicator
  const getSortIndicator = (field: string) => {
    if (sortField !== field) return null;
    return sortDirection === "asc" ? " ↑" : " ↓";
  };

  // View and edit handlers (stub)
  const handleViewStore = (id: number) => {
    console.log(`View store with ID: ${id}`);
  };

  const handleEditStore = (id: number) => {
    console.log(`Edit store with ID: ${id}`);
  };

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <h1 className="text-2xl font-bold">Manage Stores</h1>
          <Button onClick={() => setIsAddStoreModalOpen(true)}>
            <Plus className="h-4 w-4 mr-2" /> Add Store
          </Button>
        </div>

        {/* Filter & Search Section */}
        <Card>
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-grow">
                <label htmlFor="store-search" className="block text-sm font-medium text-gray-700 mb-1">
                  Search
                </label>
                <div className="relative">
                  <Input
                    id="store-search"
                    placeholder="Search by name, email, or address..."
                    value={searchTerm}
                    onChange={(e) => {
                      setSearchTerm(e.target.value);
                      setCurrentPage(1); // Reset to first page on search
                    }}
                    className="pl-10"
                  />
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                </div>
              </div>

              <div className="w-full md:w-48">
                <label htmlFor="store-filter" className="block text-sm font-medium text-gray-700 mb-1">
                  Filter By
                </label>
                <Select
                  value={filterBy}
                  onValueChange={(value) => {
                    setFilterBy(value);
                    setCurrentPage(1); // Reset to first page on filter change
                  }}
                >
                  <SelectTrigger id="store-filter">
                    <SelectValue placeholder="All Stores" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Stores</SelectItem>
                    <SelectItem value="high-rated">Highest Rated</SelectItem>
                    <SelectItem value="low-rated">Lowest Rated</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stores Table */}
        <Card>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="cursor-pointer" onClick={() => handleSort("name")}>
                    Name {getSortIndicator("name")}
                  </TableHead>
                  <TableHead className="cursor-pointer" onClick={() => handleSort("email")}>
                    Email {getSortIndicator("email")}
                  </TableHead>
                  <TableHead className="cursor-pointer" onClick={() => handleSort("address")}>
                    Address {getSortIndicator("address")}
                  </TableHead>
                  <TableHead className="cursor-pointer" onClick={() => handleSort("rating")}>
                    Rating {getSortIndicator("rating")}
                  </TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-10">
                      <div className="flex justify-center">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : paginatedStores.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-10 text-muted-foreground">
                      No stores found
                    </TableCell>
                  </TableRow>
                ) : (
                  paginatedStores.map((store) => (
                    <TableRow key={store.id}>
                      <TableCell className="font-medium">{store.name}</TableCell>
                      <TableCell>{store.email}</TableCell>
                      <TableCell className="max-w-xs truncate">{store.address}</TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <span className="text-sm mr-2">{store.avgRating.toFixed(1)}</span>
                          <StarRating rating={store.avgRating} />
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleViewStore(store.id)}
                          >
                            <Eye className="h-4 w-4 text-primary" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleEditStore(store.id)}
                          >
                            <Edit className="h-4 w-4 text-primary" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="p-4 border-t">
              <Pagination
                currentPage={currentPage}
                totalPages={totalPages}
                onPageChange={setCurrentPage}
              />
            </div>
          )}
        </Card>
      </div>

      {/* Add Store Modal */}
      <AddStoreModal
        isOpen={isAddStoreModalOpen}
        onClose={() => setIsAddStoreModalOpen(false)}
      />
    </MainLayout>
  );
}
