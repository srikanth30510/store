import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { MainLayout } from "@/components/layout/main-layout";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { StarRating } from "@/components/shared/star-rating";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Store } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Search, MapPin, Plus } from "lucide-react";
import { AddStoreModal } from "@/components/modals/add-store-modal";

interface StoreWithRating extends Store {
  avgRating: number;
  totalRatings: number;
  userRating: number | null;
}

export default function UserStores() {
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState("name-asc");
  const [isAddStoreModalOpen, setIsAddStoreModalOpen] = useState(false);
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();

  const { data: stores, isLoading } = useQuery<StoreWithRating[]>({
    queryKey: ["/api/stores"],
  });

  // Submit rating mutation
  const ratingMutation = useMutation({
    mutationFn: async ({ storeId, rating }: { storeId: number; rating: number }) => {
      const res = await apiRequest("POST", `/api/stores/${storeId}/rate`, { rating });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/stores"] });
      toast({
        title: "Rating Submitted",
        description: "Your rating has been successfully submitted.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to submit rating: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Handle rating submission
  const handleRateStore = (storeId: number, rating: number) => {
    // Check if this is the user's own store (if they are a store owner)
    if (user?.role === 'store_owner' && user?.storeId === storeId) {
      toast({
        title: "Rating Not Allowed",
        description: "You cannot rate your own store",
        variant: "destructive",
      });
      return;
    }
    
    ratingMutation.mutate({ storeId, rating });
  };

  // Filter and sort stores
  const filteredAndSortedStores = stores
    ? stores
        .filter(
          (store) =>
            searchTerm === "" ||
            store.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            store.address.toLowerCase().includes(searchTerm.toLowerCase())
        )
        .sort((a, b) => {
          switch (sortBy) {
            case "name-asc":
              return a.name.localeCompare(b.name);
            case "name-desc":
              return b.name.localeCompare(a.name);
            case "rating-desc":
              return b.avgRating - a.avgRating;
            case "rating-asc":
              return a.avgRating - b.avgRating;
            default:
              return 0;
          }
        })
    : [];

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold">Browse Stores</h1>
          <Button 
            onClick={() => setIsAddStoreModalOpen(true)}
            className="flex items-center gap-1"
          >
            <Plus className="h-4 w-4" />
            Add Store
          </Button>
        </div>

        {/* Add Store Modal */}
        <AddStoreModal 
          isOpen={isAddStoreModalOpen} 
          onClose={() => setIsAddStoreModalOpen(false)} 
        />

        {/* Search & Filter Section */}
        <Card>
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-grow">
                <label htmlFor="store-user-search" className="block text-sm font-medium text-gray-700 mb-1">
                  Search
                </label>
                <div className="relative">
                  <Input
                    id="store-user-search"
                    placeholder="Search by name or address..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                </div>
              </div>

              <div className="w-full md:w-48">
                <label htmlFor="store-sort" className="block text-sm font-medium text-gray-700 mb-1">
                  Sort By
                </label>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger id="store-sort">
                    <SelectValue placeholder="Sort by..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="name-asc">Name (A-Z)</SelectItem>
                    <SelectItem value="name-desc">Name (Z-A)</SelectItem>
                    <SelectItem value="rating-desc">Highest Rated</SelectItem>
                    <SelectItem value="rating-asc">Lowest Rated</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stores Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-6 space-y-4">
                  <div className="h-6 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-4 bg-gray-200 rounded w-full"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                  <div className="h-10 bg-gray-200 rounded w-full"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredAndSortedStores.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            No stores found matching your search criteria.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAndSortedStores.map((store) => (
              <Card key={store.id} className="overflow-hidden">
                <CardContent className="p-6">
                  <h2 className="text-lg font-bold text-primary mb-1">{store.name}</h2>
                  <p className="text-sm text-muted-foreground mb-3 flex items-start">
                    <MapPin className="h-4 w-4 mr-1 mt-0.5 text-muted-foreground" />
                    <span>{store.address}</span>
                  </p>

                  <div className="flex items-center mb-5">
                    <div className="flex mr-2">
                      <StarRating rating={typeof store.avgRating === 'number' ? store.avgRating : 0} />
                    </div>
                    <span className="text-muted-foreground">
                      ({typeof store.avgRating === 'number' ? store.avgRating.toFixed(1) : '0.0'}) from {store.totalRatings || 0} ratings
                    </span>
                  </div>

                  <p className="text-sm font-medium mb-1">Your Rating:</p>
                  <div className="flex items-center mb-4">
                    {[1, 2, 3, 4, 5].map((rating) => (
                      <button
                        key={rating}
                        onClick={() => handleRateStore(store.id, rating)}
                        className={`text-2xl ${
                          (store.userRating || 0) >= rating
                            ? "text-yellow-500"
                            : "text-muted hover:text-yellow-300 transition-colors"
                        }`}
                        disabled={ratingMutation.isPending}
                        title={`Rate ${rating} star${rating !== 1 ? 's' : ''}`}
                      >
                        ★
                      </button>
                    ))}
                    {ratingMutation.isPending ? (
                      <span className="ml-2 text-sm animate-pulse text-primary font-medium">
                        Saving...
                      </span>
                    ) : (
                      <span className="ml-2 text-sm text-muted-foreground">
                        {store.userRating ? `Your rating: ${store.userRating}` : "Not rated yet"}
                      </span>
                    )}
                  </div>

                  <Button
                    className="w-full"
                    variant="outline"
                    onClick={() => setLocation(`/store/${store.id}`)}
                  >
                    View Details
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </MainLayout>
  );
}
