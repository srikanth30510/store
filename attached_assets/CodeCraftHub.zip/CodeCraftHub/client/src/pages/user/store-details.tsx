import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute, useLocation } from "wouter";
import { MainLayout } from "@/components/layout/main-layout";
import { Button } from "@/components/ui/button";
import { StarRating } from "@/components/shared/star-rating";
import { RatingDistribution } from "@/components/shared/rating-distribution";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Loader2, ArrowLeft, MapPin, Mail, Phone } from "lucide-react";
import { Store } from "@shared/schema";

interface StoreWithDetails {
  id: number;
  name: string;
  email: string;
  address: string;
  createdAt: string;
  avgRating: number;
  totalRatings: number;
  userRating: number | null;
  ratingDistribution: { rating: number; count: number }[];
}

interface Rating {
  id: number;
  userId: number;
  storeId: number;
  rating: number;
  createdAt: string;
  user: {
    name: string;
    email: string;
  };
}

export default function StoreDetails() {
  const [, setLocation] = useLocation();
  const [, params] = useRoute<{ id: string }>("/store/:id");
  const storeId = params?.id ? parseInt(params.id) : null;
  const { toast } = useToast();
  const { user } = useAuth();
  
  // Redirect if no store ID is provided
  useEffect(() => {
    if (!storeId) {
      setLocation("/");
    }
  }, [storeId, setLocation]);

  // Fetch store details
  const { data: store, isLoading: isLoadingStore } = useQuery<StoreWithDetails>({
    queryKey: [`/api/stores/${storeId}`],
    enabled: !!storeId,
  });

  // Fetch store ratings
  const { data: ratings, isLoading: isLoadingRatings } = useQuery<Rating[]>({
    queryKey: [`/api/stores/${storeId}/ratings`],
    enabled: !!storeId,
  });

  // Submit rating mutation
  const ratingMutation = useMutation({
    mutationFn: async (rating: number) => {
      if (!storeId) throw new Error("Store ID is missing");
      const res = await apiRequest("POST", `/api/stores/${storeId}/rate`, { rating });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/stores/${storeId}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/stores/${storeId}/ratings`] });
      toast({
        title: "Rating Submitted",
        description: "Your rating has been successfully submitted.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to submit rating: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Handle rating submission
  const handleRateStore = (rating: number) => {
    // Check if this is the user's own store (if they are a store owner)
    if (user?.role === 'store_owner' && user?.storeId === storeId) {
      toast({
        title: "Rating Not Allowed",
        description: "You cannot rate your own store",
        variant: "destructive",
      });
      return;
    }
    
    ratingMutation.mutate(rating);
  };

  if (!storeId) {
    return null;
  }

  if (isLoadingStore) {
    return (
      <MainLayout>
        <div className="flex items-center justify-center min-h-screen">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  if (!store) {
    return (
      <MainLayout>
        <div className="text-center py-12">
          <h2 className="text-2xl font-bold mb-2">Store Not Found</h2>
          <p className="text-muted-foreground mb-6">
            The store you're looking for doesn't exist or has been removed.
          </p>
          <Button onClick={() => setLocation("/")}>
            Back to Stores
          </Button>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="space-y-8">
        {/* Back button */}
        <Button
          variant="outline"
          className="flex items-center gap-1"
          onClick={() => setLocation("/")}
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Stores
        </Button>

        {/* Store header */}
        <div className="space-y-4">
          <h1 className="text-3xl font-bold text-primary">{store.name}</h1>
          
          <div className="flex items-center gap-6 flex-wrap">
            <div className="flex items-center gap-1">
              <MapPin className="h-5 w-5 text-muted-foreground" />
              <span>{store.address}</span>
            </div>
            
            <div className="flex items-center gap-1">
              <Mail className="h-5 w-5 text-muted-foreground" />
              <a href={`mailto:${store.email}`} className="hover:underline">
                {store.email}
              </a>
            </div>
          </div>
        </div>

        {/* Rating overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div className="space-y-2">
              <h2 className="text-xl font-semibold">Store Rating</h2>
              <div className="flex items-center gap-4">
                <div className="flex items-center">
                  <div className="text-4xl font-bold mr-2">
                    {typeof store.avgRating === 'number' ? store.avgRating.toFixed(1) : '0.0'}
                  </div>
                  <div className="flex flex-col">
                    <StarRating 
                      rating={typeof store.avgRating === 'number' ? store.avgRating : 0} 
                      size="large" 
                    />
                    <span className="text-sm text-muted-foreground mt-1">
                      from {store.totalRatings || 0} ratings
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {store.ratingDistribution && (
              <div className="space-y-3">
                <h3 className="text-lg font-medium">Rating Distribution</h3>
                <RatingDistribution 
                  distribution={store.ratingDistribution} 
                  totalRatings={store.totalRatings} 
                />
              </div>
            )}

            <div className="space-y-3">
              <h3 className="text-lg font-medium">Your Rating</h3>
              <div className="flex items-center">
                {[1, 2, 3, 4, 5].map((rating) => (
                  <button
                    key={rating}
                    onClick={() => handleRateStore(rating)}
                    className={`text-3xl ${
                      (store.userRating || 0) >= rating
                        ? "text-yellow-500"
                        : "text-muted hover:text-yellow-300 transition-colors"
                    }`}
                    disabled={ratingMutation.isPending}
                    title={`Rate ${rating} star${rating !== 1 ? 's' : ''}`}
                  >
                    ★
                  </button>
                ))}
                {ratingMutation.isPending ? (
                  <span className="ml-3 text-sm animate-pulse text-primary font-medium">
                    Saving...
                  </span>
                ) : (
                  <span className="ml-3 text-sm text-muted-foreground">
                    {store.userRating 
                      ? `Your rating: ${store.userRating}` 
                      : "You haven't rated this store yet"
                    }
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Recent ratings */}
          <div className="space-y-4">
            <h2 className="text-xl font-semibold">Recent Ratings</h2>
            {isLoadingRatings ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            ) : !ratings || ratings.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground border rounded-lg">
                No ratings yet. Be the first to rate this store!
              </div>
            ) : (
              <div className="space-y-4">
                {ratings.map((rating) => (
                  <div 
                    key={rating.id} 
                    className="p-4 border rounded-lg"
                  >
                    <div className="flex justify-between items-start mb-2">
                      <div className="font-medium">{rating.user.name}</div>
                      <div className="flex">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <span 
                            key={star}
                            className={`text-lg ${
                              rating.rating >= star 
                                ? "text-yellow-500" 
                                : "text-muted"
                            }`}
                          >
                            ★
                          </span>
                        ))}
                      </div>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {new Date(rating.createdAt).toLocaleDateString()}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </MainLayout>
  );
}