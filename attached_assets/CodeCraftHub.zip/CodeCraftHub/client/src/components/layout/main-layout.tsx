import { ReactNode, useState } from "react";
import { useLocation, Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { 
  LayoutDashboard, Store, Users, User, LogOut, Menu, X, 
  Home, ChevronDown
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

type MainLayoutProps = {
  children: ReactNode;
};

export function MainLayout({ children }: MainLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();

  const isAdmin = user?.role === "admin";
  const isStoreOwner = user?.role === "store_owner";
  const isNormalUser = user?.role === "user";

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const closeSidebarIfMobile = () => {
    if (window.innerWidth < 768) {
      setSidebarOpen(false);
    }
  };

  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-gray-50">
      {/* Sidebar */}
      <aside
        className={`bg-primary text-white w-full md:w-64 flex-shrink-0 md:flex flex-col fixed md:sticky top-0 h-full z-20 transform transition-transform duration-200 ease-in-out ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
        }`}
      >
        <div className="p-4 border-b border-primary-light flex items-center justify-between">
          <h1 className="text-xl font-bold">Store Ratings</h1>
          <button
            className="md:hidden text-white focus:outline-none"
            onClick={toggleSidebar}
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        {/* Admin Navigation */}
        {isAdmin && (
          <nav className="py-4 flex-grow">
            <div className="px-4 py-2 text-sm text-white/50 uppercase font-medium">
              Admin Dashboard
            </div>
            <Link href="/admin/dashboard">
              <a
                className={`flex items-center px-4 py-2 text-white hover:bg-primary-dark transition-colors ${
                  location === "/admin/dashboard" ? "bg-primary-dark" : ""
                }`}
                onClick={closeSidebarIfMobile}
              >
                <LayoutDashboard className="h-4 w-4 mr-2" /> Dashboard
              </a>
            </Link>
            <Link href="/admin/stores">
              <a
                className={`flex items-center px-4 py-2 text-white hover:bg-primary-dark transition-colors ${
                  location === "/admin/stores" ? "bg-primary-dark" : ""
                }`}
                onClick={closeSidebarIfMobile}
              >
                <Store className="h-4 w-4 mr-2" /> Stores
              </a>
            </Link>
            <Link href="/admin/users">
              <a
                className={`flex items-center px-4 py-2 text-white hover:bg-primary-dark transition-colors ${
                  location === "/admin/users" ? "bg-primary-dark" : ""
                }`}
                onClick={closeSidebarIfMobile}
              >
                <Users className="h-4 w-4 mr-2" /> Users
              </a>
            </Link>
          </nav>
        )}

        {/* Normal User Navigation */}
        {isNormalUser && (
          <nav className="py-4 flex-grow">
            <div className="px-4 py-2 text-sm text-white/50 uppercase font-medium">
              User Menu
            </div>
            <Link href="/user/stores">
              <a
                className={`flex items-center px-4 py-2 text-white hover:bg-primary-dark transition-colors ${
                  location === "/user/stores" ? "bg-primary-dark" : ""
                }`}
                onClick={closeSidebarIfMobile}
              >
                <Store className="h-4 w-4 mr-2" /> Stores
              </a>
            </Link>
            <Link href="/user/profile">
              <a
                className={`flex items-center px-4 py-2 text-white hover:bg-primary-dark transition-colors ${
                  location === "/user/profile" ? "bg-primary-dark" : ""
                }`}
                onClick={closeSidebarIfMobile}
              >
                <User className="h-4 w-4 mr-2" /> My Profile
              </a>
            </Link>
          </nav>
        )}

        {/* Store Owner Navigation */}
        {isStoreOwner && (
          <nav className="py-4 flex-grow">
            <div className="px-4 py-2 text-sm text-white/50 uppercase font-medium">
              Store Dashboard
            </div>
            <Link href="/store-owner/dashboard">
              <a
                className={`flex items-center px-4 py-2 text-white hover:bg-primary-dark transition-colors ${
                  location === "/store-owner/dashboard" ? "bg-primary-dark" : ""
                }`}
                onClick={closeSidebarIfMobile}
              >
                <LayoutDashboard className="h-4 w-4 mr-2" /> Dashboard
              </a>
            </Link>
            <Link href="/store-owner/profile">
              <a
                className={`flex items-center px-4 py-2 text-white hover:bg-primary-dark transition-colors ${
                  location === "/store-owner/profile" ? "bg-primary-dark" : ""
                }`}
                onClick={closeSidebarIfMobile}
              >
                <Store className="h-4 w-4 mr-2" /> Store Profile
              </a>
            </Link>
          </nav>
        )}

        {/* Common Footer Navigation */}
        <div className="p-4 border-t border-primary-light mt-auto">
          <div className="flex items-center mb-4">
            <User className="h-4 w-4 mr-2" />
            <span className="font-medium">{user?.name}</span>
          </div>
          <Button
            variant="outline"
            className="w-full bg-white text-primary hover:bg-gray-100"
            onClick={handleLogout}
            disabled={logoutMutation.isPending}
          >
            <LogOut className="h-4 w-4 mr-2" /> Logout
          </Button>
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="md:hidden bg-primary text-white p-4 flex items-center justify-between sticky top-0 z-10">
        <h1 className="text-xl font-bold">Store Ratings</h1>
        <button
          className="text-white focus:outline-none"
          onClick={toggleSidebar}
        >
          <Menu className="h-6 w-6" />
        </button>
      </div>

      {/* Mobile Navigation for logged in users */}
      <div className="md:hidden bg-white border-b sticky top-14 z-10 px-4 py-2 flex items-center justify-between">
        {isAdmin && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-8 flex items-center">
                Admin <ChevronDown className="ml-1 h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start">
              <Link href="/admin/dashboard">
                <DropdownMenuItem className="cursor-pointer">
                  <LayoutDashboard className="h-4 w-4 mr-2" /> Dashboard
                </DropdownMenuItem>
              </Link>
              <Link href="/admin/stores">
                <DropdownMenuItem className="cursor-pointer">
                  <Store className="h-4 w-4 mr-2" /> Stores
                </DropdownMenuItem>
              </Link>
              <Link href="/admin/users">
                <DropdownMenuItem className="cursor-pointer">
                  <Users className="h-4 w-4 mr-2" /> Users
                </DropdownMenuItem>
              </Link>
            </DropdownMenuContent>
          </DropdownMenu>
        )}

        {isNormalUser && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-8 flex items-center">
                User <ChevronDown className="ml-1 h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start">
              <Link href="/user/stores">
                <DropdownMenuItem className="cursor-pointer">
                  <Store className="h-4 w-4 mr-2" /> Stores
                </DropdownMenuItem>
              </Link>
              <Link href="/user/profile">
                <DropdownMenuItem className="cursor-pointer">
                  <User className="h-4 w-4 mr-2" /> Profile
                </DropdownMenuItem>
              </Link>
            </DropdownMenuContent>
          </DropdownMenu>
        )}

        {isStoreOwner && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-8 flex items-center">
                Store <ChevronDown className="ml-1 h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start">
              <Link href="/store-owner/dashboard">
                <DropdownMenuItem className="cursor-pointer">
                  <LayoutDashboard className="h-4 w-4 mr-2" /> Dashboard
                </DropdownMenuItem>
              </Link>
              <Link href="/store-owner/profile">
                <DropdownMenuItem className="cursor-pointer">
                  <Store className="h-4 w-4 mr-2" /> Store Profile
                </DropdownMenuItem>
              </Link>
            </DropdownMenuContent>
          </DropdownMenu>
        )}

        <Link href="/">
          <a className="flex items-center text-gray-600">
            <Home className="h-4 w-4 mr-1" /> Home
          </a>
        </Link>
      </div>

      {/* Main Content */}
      <main className="flex-grow p-4 md:p-8 overflow-auto">
        <div className="max-w-7xl mx-auto">{children}</div>
      </main>

      {/* Overlay for mobile sidebar */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-10 md:hidden"
          onClick={toggleSidebar}
        ></div>
      )}
    </div>
  );
}
