interface RatingDistributionProps {
  distribution: { rating: number; count: number }[];
  totalRatings: number;
}

export function RatingDistribution({
  distribution,
  totalRatings,
}: RatingDistributionProps) {
  // Sort the distribution by rating (5 to 1)
  const sortedDistribution = [...distribution].sort((a, b) => b.rating - a.rating);

  return (
    <div className="space-y-2">
      {sortedDistribution.map((item) => {
        const percentage = totalRatings > 0 ? (item.count / totalRatings) * 100 : 0;
        
        return (
          <div key={item.rating} className="flex items-center gap-2">
            <div className="w-24 flex justify-between items-center">
              <span className="text-sm font-medium">{item.rating} stars</span>
              <span className="text-sm text-muted-foreground">({item.count})</span>
            </div>
            
            <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-yellow-500 rounded-full"
                style={{ width: `${percentage}%` }}
              />
            </div>
            
            <div className="w-12 text-right">
              <span className="text-xs text-muted-foreground">
                {percentage.toFixed(0)}%
              </span>
            </div>
          </div>
        );
      })}
      
      {distribution.length === 0 && (
        <div className="text-center py-2 text-muted-foreground text-sm">
          No ratings yet
        </div>
      )}
    </div>
  );
}