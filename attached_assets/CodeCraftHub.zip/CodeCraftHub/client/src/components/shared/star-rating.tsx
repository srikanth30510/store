import { useState } from "react";

interface StarRatingProps {
  rating: number;
  size?: "small" | "medium" | "large";
  interactive?: boolean;
  onRatingChange?: (rating: number) => void;
  className?: string;
}

export function StarRating({
  rating,
  size = "medium",
  interactive = false,
  onRatingChange,
  className = "",
}: StarRatingProps) {
  const [hoverRating, setHoverRating] = useState(0);
  
  const getStarSize = () => {
    switch (size) {
      case "small":
        return "text-lg";
      case "medium":
        return "text-xl";
      case "large":
        return "text-2xl";
      default:
        return "text-xl";
    }
  };

  const renderStar = (position: number) => {
    const isFilled = interactive
      ? position <= (hoverRating || rating)
      : position <= rating;

    return (
      <span
        key={position}
        className={`${
          isFilled ? "text-yellow-500" : "text-gray-300"
        } ${getStarSize()} ${
          interactive ? "cursor-pointer hover:text-yellow-300 transition-colors" : ""
        }`}
        onMouseEnter={interactive ? () => setHoverRating(position) : undefined}
        onMouseLeave={interactive ? () => setHoverRating(0) : undefined}
        onClick={interactive && onRatingChange ? () => onRatingChange(position) : undefined}
      >
        ★
      </span>
    );
  };

  return (
    <div className={`flex ${className}`}>
      {[1, 2, 3, 4, 5].map((position) => renderStar(position))}
    </div>
  );
}