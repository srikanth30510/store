import { QueryClientProvider } from "@tanstack/react-query";
import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { AuthProvider, useAuth } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";
import { Toaster } from "@/components/ui/toaster";

// Auth Page
import AuthPage from "@/pages/auth-page";
import NotFound from "@/pages/not-found";

// Admin Pages
import AdminDashboard from "@/pages/admin/dashboard";
import AdminStores from "@/pages/admin/stores";
import AdminUsers from "@/pages/admin/users";

// Normal User Pages
import UserStores from "@/pages/user/stores";
import UserProfile from "@/pages/user/profile";
import StoreDetails from "@/pages/user/store-details";

// Store Owner Pages
import StoreDashboard from "@/pages/store-owner/dashboard";
import StoreProfile from "@/pages/store-owner/profile";

function Router() {
  return (
    <Switch>
      {/* Public route */}
      <Route path="/auth" component={AuthPage} />

      {/* Role-based Home route */}
      <Route path="/">
        {() => {
          const { user, isLoading } = useAuth();
          
          if (isLoading) {
            return (
              <div className="flex items-center justify-center min-h-screen">
                <div className="h-8 w-8 animate-spin border-t-2 border-primary rounded-full" />
              </div>
            );
          }
          
          if (!user) {
            return <Redirect to="/auth" />;
          }
          
          switch (user.role) {
            case "admin":
              return <AdminDashboard />;
            case "user":
              return <UserStores />;
            case "store_owner":
              return <StoreDashboard />;
            default:
              return <Redirect to="/auth" />;
          }
        }}
      </Route>

      {/* Admin routes */}
      <ProtectedRoute
        path="/admin/dashboard"
        component={() => <AdminDashboard />}
        requiredRole="admin"
      />
      <ProtectedRoute
        path="/admin/stores"
        component={() => <AdminStores />}
        requiredRole="admin"
      />
      <ProtectedRoute
        path="/admin/users"
        component={() => <AdminUsers />}
        requiredRole="admin"
      />

      {/* Normal User routes */}
      <ProtectedRoute
        path="/user/stores"
        component={() => <UserStores />}
        requiredRole="user"
      />
      <ProtectedRoute
        path="/user/profile"
        component={() => <UserProfile />}
        requiredRole="user"
      />
      <ProtectedRoute
        path="/store/:id"
        component={({params}) => <StoreDetails storeId={parseInt(params.id)} />}
      />

      {/* Store Owner routes */}
      <ProtectedRoute
        path="/store-owner/dashboard"
        component={() => <StoreDashboard />}
        requiredRole="store_owner"
      />
      <ProtectedRoute
        path="/store-owner/profile"
        component={() => <StoreProfile />}
        requiredRole="store_owner"
      />

      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
