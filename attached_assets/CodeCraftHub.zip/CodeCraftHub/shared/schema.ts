import { pgTable, text, serial, integer, boolean, timestamp, varchar, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Enum for user roles
export const roleEnum = pgEnum('role', ['admin', 'user', 'store_owner']);

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 60 }).notNull(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  password: text("password").notNull(),
  address: varchar("address", { length: 400 }).notNull(),
  role: roleEnum("role").notNull().default('user'),
  storeId: integer("store_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Users schema for insert with validation
export const insertUserSchema = createInsertSchema(users, {
  name: z.string().min(20).max(60),
  email: z.string().email(),
  password: z.string().min(8).max(16).regex(/^(?=.*[A-Z])(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]).*$/),
  address: z.string().max(400),
  role: z.enum(['admin', 'user', 'store_owner']),
}).omit({ id: true, createdAt: true });

// Stores table
export const stores = pgTable("stores", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 60 }).notNull(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  address: varchar("address", { length: 400 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Stores schema for insert with validation
export const insertStoreSchema = createInsertSchema(stores, {
  name: z.string().min(20).max(60),
  email: z.string().email(),
  address: z.string().max(400),
}).omit({ id: true, createdAt: true });

// Ratings table
export const ratings = pgTable("ratings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  storeId: integer("store_id").notNull().references(() => stores.id, { onDelete: 'cascade' }),
  rating: integer("rating").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Ratings schema for insert with validation
export const insertRatingSchema = createInsertSchema(ratings, {
  rating: z.number().int().min(1).max(5),
}).omit({ id: true, createdAt: true });

// Define relations
export const usersRelations = relations(users, ({ one }) => ({
  store: one(stores, {
    fields: [users.storeId],
    references: [stores.id],
  }),
}));

export const storesRelations = relations(stores, ({ many }) => ({
  ratings: many(ratings),
  storeOwners: many(users),
}));

export const ratingsRelations = relations(ratings, ({ one }) => ({
  user: one(users, {
    fields: [ratings.userId],
    references: [users.id],
  }),
  store: one(stores, {
    fields: [ratings.storeId],
    references: [stores.id],
  }),
}));

// Export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Store = typeof stores.$inferSelect;
export type InsertStore = z.infer<typeof insertStoreSchema>;
export type Rating = typeof ratings.$inferSelect;
export type InsertRating = z.infer<typeof insertRatingSchema>;

// Login schema
export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string(),
});

export type LoginData = z.infer<typeof loginSchema>;

// Password update schema
export const passwordUpdateSchema = z.object({
  currentPassword: z.string(),
  newPassword: z.string().min(8).max(16)
    .regex(/^(?=.*[A-Z])(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]).*$/),
  confirmNewPassword: z.string(),
}).refine((data) => data.newPassword === data.confirmNewPassword, {
  message: "Passwords do not match",
  path: ["confirmNewPassword"],
});

export type PasswordUpdateData = z.infer<typeof passwordUpdateSchema>;
